# Shree Choudhari portfolio for GitHub Pages

Prepared from the latest published portfolio, version 9, on 6 October 2026.
Includes the interactive 3D robot, project pages, certificates and current corrections.

## Publish

1. Sign in as Shree241. Create a repository named Shree241.github.io. Public visibility works with GitHub Free.
2. Extract this ZIP. Upload the CONTENTS of the Shree241.github.io folder to the repository, keeping the assets, projects and education folders intact. index.html must be at the repository root. Upload the files, not the ZIP itself.
3. Commit the upload to main.
4. Open Settings > Pages. Choose Deploy from a branch, main, and /(root), then Save.
5. Wait for publication, then open https://shree241.github.io/. This address is a planned destination, not confirmation of an existing live deployment.

## Connect shreechoudhari.info

First confirm that the GitHub Pages copy works. Then verify domain ownership in your GitHub account's Pages settings and add shreechoudhari.info under this repository's Settings > Pages > Custom domain.

At your domain provider, point the root domain to GitHub using these four A records:

| Type | Name | Value |
| --- | --- | --- |
| A | @ | 185.199.108.153 |
| A | @ | 185.199.109.153 |
| A | @ | 185.199.110.153 |
| A | @ | 185.199.111.153 |
| CNAME | www | shree241.github.io |

These replace the root web-hosting A records previously supplied for the current hosting service. Keep unrelated email records. The GitHub verification TXT value comes from your own account; it cannot be provided in advance.

When domain validation finishes, enable Enforce HTTPS. Update the og:url metadata in the HTML files from https://shree241.github.io to https://shreechoudhari.info. GitHub creates the CNAME file when you save the custom domain; preserve that file on later uploads.

This package does not activate or purchase the domain. Domain setup and account access are still required.

## Sources

- https://docs.github.com/en/pages/quickstart
- https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

## Updates

This is a ready-to-publish static copy. No build command or paid GitHub plan is needed for a public repository. Later edits to the existing hosted portfolio will need to be copied into this repository before they appear on GitHub Pages.
